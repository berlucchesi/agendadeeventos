<?php
@session_start();

require_once('../model/calendario.model.php');

if(isset($_POST['args']) && !empty($_POST['args']))
{
    $args = json_decode(stripslashes($_POST['args']));
    
    switch($args[0]){
            
        case 'carregaCalendario':
            carregaCalendario($args);
        break;
            
        case'avancarMes':
            avancarMes($args);
        break;
            
        case'voltarMes':
            voltarMes($args);
        break;
            
        default:
            
    }//switch
    
}

function avancarMes()
{
    
    $_SESSION['ano'] = $args[2];
    $_SESSION['mes'] = $args[1];
    $data = '01/'.$args[1].'/'.$args[2];
    
    $calendario = new Calendario;
    return $this->carregaCalendario($calendario->proximoMes($data));
}

function voltarMes()
{
    
    $_SESSION['ano'] = $args[2];
    $_SESSION['mes'] = $args[1];
    $data = '01/'.$args[1].'/'.$args[2];
    
    $calendario = new Calendario;
    return $this->carregaCalendario($calendario->anteriorMes('01/'.$_SESSION['mes'].'/'.$_SESSION['ano']));
}

function carregaCalendario($args)
{
    
    $_SESSION['ano'] = $args[2];
    $_SESSION['mes'] = $args[1];
    $data = '01/'.$args[1].'/'.$args[2];
    
    $calendario = new Calendario;
    $calendario->constroiCalendario($data);
    
}

?>


