<?php

/*
 * @Autor:   Bernardo Figueiredo Lucchesi
 * @Contato: bernardolucchesi@gmail.com
 * @Site:    www.brnardo.com.br
 */

require_once('../model/teste.model.php');

$args = array();

/******************************************
 * Tratamento de erro e chamada da função *
 ******************************************/

if(isset($_POST['args'])):

    $args = json_decode(stripslashes($_POST['args']));

endif; //decodifica e insere os argumentos no array;

if(!empty($args) && function_exists($args[0]) ):
    $args[0]($args);
elseif(!function_exists($args[0])):
    echo 'O metodo '.$args[0].' não existe.';
else:
    echo 'A lista de argumentos está vazia.';
endif; //chama a função passada pelo args[0]

//fim do tratamento de erro e chamada da função

/******************************************
 *      Chamada das funções do Modelo     *
 ******************************************/

function callTesteA($args)
{
    $teste = new Teste;
    $teste->testeA($args);
} 

function callTesteB($args)
{
    $teste = new Teste;
    $teste->testeB($args);
} 

function callTesteC($args)
{
    $teste = new Teste;
    $teste->testeC($args);
} 

function callTesteD($args)
{
    $teste = new Teste;
    $teste->testeD($args);
} 

function callEsvaziar($args)
{
    $teste = new Teste;
    $teste->esvaziar($args);
}
?>
