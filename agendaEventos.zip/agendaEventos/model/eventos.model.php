<?php

@session_start();

require_once('calendario.model.php');

class Eventos
{
    
    function exibirEventos($data)
    {
        
        echo '<table id="tbEventos" class="tbEventos">
                <tr><td class="title" colspan="5">Eventos de '. substr($_SESSION['data'], -7).'</td></tr>';
        
        if(empty($_SESSION['eventos'])):
            echo '<tr><td class="aviso" colspan="5">Não existem eventos cadastrados!</td></tr>
                  </table>';
            return;
        endif;
        
        $cont = 0;
        $bg = array(0=>'cinza', 1=>'');
        $bgc = 0;
        
        foreach($_SESSION['eventos'] as $a):
        
            if(substr($a['data'], -7) === substr($_SESSION['data'], -7))
            {
                $cont++;
                
                echo '<tr class="'.$bg[$bgc].'">
                        <td>'.$a['data'].'</td>
                        <td>'.$a['nome'].'</td>
                        <td>'. $a['tipo'] .'</td>
                        <td> <a id="deletarEvento" href="index.php?apagar='. $a['id'] .'"> Apagar </a> </td>
                        <td> <a id="editaEventoBtn" href="index.php?editar='. $a['id'] .'"> Editar </a> </td>
                      </tr>
                      <tr class="'.$bg[$bgc].'">
                        <td colspan="3">'. $a['local'] .'</td>
                        <td>'. $a['inicio'] .'</td>
                        <td>'. $a['termino'] .'</td>
                      </tr>
                      <tr class="'.$bg[$bgc].'"><td colspan="5">'. $a['observacoes'] .'</td></tr>';
            }
        
            if($bgc===1) $bgc = 0;
            else $bgc = 1;
        
        endforeach;
        
        if($cont == 0)
            echo '<tr><td class="aviso" colspan="5">Não existem eventos cadastrados neste mês.</td></tr>';
        
        
        echo '</table>';
        
        return;
        
    }
    
    function inserirEvento($args)
    {
        
        $calendario = new Calendario;
        
        if(!$calendario->checaData($_POST['addEvtData'])):
            echo '<div class="msgAviso">A data do evento deve ser uma data válida.</div>';
            return;
        endif;
            
        
        $evtId = $args + 1;
        $_SESSION['ultimoId'] = $evtId;
        
        $_SESSION['eventos'][$evtId]['id']         = $evtId;
        $_SESSION['eventos'][$evtId]['data']       = $_POST['addEvtData'];
        $_SESSION['eventos'][$evtId]['nome']       = $_POST['addEvtNome'];
        $_SESSION['eventos'][$evtId]['tipo']       = $_POST['addEvtTipo'];
        $_SESSION['eventos'][$evtId]['local']      = $_POST['addEvtLocal'];
        $_SESSION['eventos'][$evtId]['inicio']     = $_POST['addEvtInicio'];
        $_SESSION['eventos'][$evtId]['termino']    = $_POST['addEvtTermino'];
        $_SESSION['eventos'][$evtId]['observacoes']= $_POST['addEvtObs'];
        
        if(!empty($_POST['addEvtRepetir'])):
            $repetir = str_replace(' ', '', $_POST['addEvtRepetir']);
            $repetir = explode(',', $repetir);
        
            foreach($repetir as $repEvt):
        
                if(!$calendario->checaData($repEvt)):
                    echo 'A data ' .$repEvt. ' é inválida.<br>';
                else:
        
                $evtId++;
                $_SESSION['ultimoId'] = $evtId;

                $_SESSION['eventos'][$evtId]['id']         = $evtId;
                $_SESSION['eventos'][$evtId]['data']       = $repEvt;
                $_SESSION['eventos'][$evtId]['nome']       = $_POST['addEvtNome'];
                $_SESSION['eventos'][$evtId]['tipo']       = $_POST['addEvtTipo'];
                $_SESSION['eventos'][$evtId]['local']      = $_POST['addEvtLocal'];
                $_SESSION['eventos'][$evtId]['inicio']     = $_POST['addEvtInicio'];
                $_SESSION['eventos'][$evtId]['termino']    = $_POST['addEvtTermino'];
                $_SESSION['eventos'][$evtId]['observacoes']= $_POST['addEvtObs'];
        
                endif;
            endforeach;
        
        endif;
        
        echo '<div class="msgSucesso">Sucesso! Id: '.$evtId.'.</div>';
        
    }
    
    function apagarEvento($args)
    {
        if(isset($_SESSION['eventos'][$args]))
        {
            unset($_SESSION['eventos'][$args]);
            echo '<div class="msgSucesso"> Evento: '.$args.' deletado. </div>';
        }
        else
            echo '<div class="msgAviso"> Evento id: '.$args.' não existe. </div>';
    }
    
    function editarEvento()
    {
        
        $evtId = $_POST['addEvtId'];
        $calendario = new Calendario;
        
        if(!$calendario->checaData($_POST['addEvtData'])):
            echo '<div class="msgAviso">A data do evento deve ser uma data válida.</div>';
            return;
        endif;
        
        $_SESSION['eventos'][$evtId]['id']         = $evtId;
        $_SESSION['eventos'][$evtId]['data']       = $_POST['addEvtData'];
        $_SESSION['eventos'][$evtId]['nome']       = $_POST['addEvtNome'];
        $_SESSION['eventos'][$evtId]['tipo']       = $_POST['addEvtTipo'];
        $_SESSION['eventos'][$evtId]['local']      = $_POST['addEvtLocal'];
        $_SESSION['eventos'][$evtId]['inicio']     = $_POST['addEvtInicio'];
        $_SESSION['eventos'][$evtId]['termino']    = $_POST['addEvtTermino'];
        $_SESSION['eventos'][$evtId]['observacoes']= $_POST['addEvtObs'];
        
        echo '<div class="msgSucesso">O evento id: '. $evtId .' foi editado!</div>';
    }
    
}

?>