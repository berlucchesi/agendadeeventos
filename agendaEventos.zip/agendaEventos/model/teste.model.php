<?php

/*
 * @Autor:   Bernardo Figueiredo Lucchesi
 * @Contato: bernardolucchesi@gmail.com
 * @Site:    www.brnardo.com.br
 */

class Teste
{
    
    function testeA($args)
    {
        echo 'Este é o teste A <br>' .urldecode($args[1]);
    }
    
    function testeB($args)
    {
        echo 'Este é o teste B';
    }
    
    function testeC($args)
    {
        echo 'Este é o teste C';
    }
    
    function testeD($args)
    {
        echo 'Este é o teste D';
    }
    
    function esvaziar($args)
    {
        echo 'Esta caixa está vazia.';
    }
    
}
?>