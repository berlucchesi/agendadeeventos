/*
 * @Autor:   Bernardo Figueiredo Lucchesi
 * @Contato: bernardolucchesi@gmail.com
 * @Site:    www.brnardo.com.br
 */


/*
callTesteController(
    url    => localização do arquivo php que será carregado,  ex.: 'lib/file.php',
    method => nome da função que será chamada no controlador, ex.: 'listaNomes',
    tagId  => ID do bloco onde o conteúdo da página será atualizado ex.: '#content',
    formId => ID do formulário de onde serão retirados os argumentos, caso haja algum, ex.: '#formContato'.
);
*/
function callController(url, method, tagId, formId)
{

    var args = new Array();
    args[0] = method;
    
    if ($(formId).length === 1) 
    {
        args[1] = $(formId).serialize();
        $( "#results" ).text( args[1] );
    }
    else 
    {
        alert('undefined');
    }
    
    var strArgs = JSON.stringify(args);
    
    $.ajax({
        url: url,
        method: "POST",
        data: {args: strArgs},
        success: function(data){
            $(tagId).html(data);
        },
        error: function(xhr, status, error) {
            alert(xhr.responseText);
        }
    });
    
}//callTesteController

$(document).ready(function(){

    //Ativa o botão com ID #clicaA
    $(document).on('click', '#clicaA', function(){
        callController('control/teste.controller.php', 'callTesteA', '#box1', '#boxOptions');
    });
    
    //Ativa o botão com ID #clicaB
    $(document).on('click', '#clicaB', function(){
        callController('control/teste.controller.php', 'callTesteB', '#box2', '#boxOptions');
    });
    
    //Ativa o botão com ID #clicaC
    $(document).on('click', '#clicaC', function(){
        callController('control/teste.controller.php', 'callTesteC', '#box3', '#boxOptions');
    });
    
    //Ativa o botão com ID #clicaD
    $(document).on('click', '#clicaD', function(){
        callController('control/teste.controller.php', 'callTesteD', '#box4', '#boxOptions');
    });
    
    //Ativa o botão com ID #esvaziaA
    $(document).on('click', '#esvaziaA', function(){
        callController('control/teste.controller.php', 'callEsvaziar', '#box1', '');
    });
    
    //Ativa o botão com ID #esvaziaB
    $(document).on('click', '#esvaziaB', function(){
        callController('control/teste.controller.php', 'callEsvaziar', '#box2', '');
    });
    
    //Ativa o botão com ID #esvaziaC
    $(document).on('click', '#esvaziaC', function(){
        callController('control/teste.controller.php', 'callEsvaziar', '#box3', '');
    });
    
    //Ativa o botão com ID #esvaziaD
    $(document).on('click', '#esvaziaD', function(){
        callController('control/teste.controller.php', 'callEsvaziar', '#box4', '');
    });
                  
});


