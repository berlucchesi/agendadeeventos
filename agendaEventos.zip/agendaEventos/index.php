<?php
session_start();

if(!isset($_SESSION['eventos']))
    $_SESSION['eventos'] = array();

echo 'Eventos cadastrados: '. sizeof($_SESSION['eventos']) .'<br>';

if(!isset($_SESSION['ultimoId']))
    $_SESSION['ultimoId']= 0;

if(!isset($_SESSION['anos']))
    $_SESSION['anos']    = array();

if(empty($_SESSION['anos']))
    $_SESSION['anos'][] = 2018;

if(!isset($_SESSION['data']))
    $_SESSION['data'] = date('d/m/Y');

?>
<html>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <head>
    <!-- 
    @Autor:   Bernardo Figueiredo Lucchesi
    @Contato: bernardolucchesi@gmail.com
    @Site:    www.brnardo.com.br
    -->
    <title>Agenda de Eventos</title>
    <link rel="stylesheet" href="template/styles.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat|Poiret+One" rel="stylesheet">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
    <script src="js/ajax.js"></script>
   
    </head>
    
    <body id="corpo">
        <div id="wrapper">
        
        <header>
            <h1>- Agenda de Eventos -</h1>
            <a class="menu-header" href="index.php"> Home </a> <a class="menu-header reset" href="index.php?act=clear"> Limpar sessão </a>
        </header>
        
        <div id="content_calendario" class="content-calendario">
            <p>
            <h2> - Calendário - </h2></p>
            
            <?php
            require_once('model/calendario.model.php');
            require_once('model/eventos.model.php');
            
            $calendario = new Calendario;
            $eventos = new Eventos;
            
            //Limpar Eventos
            if(isset($_GET['act']) && $_GET['act'] == 'clear')
            {
                
                echo '<div class="msgBox"> Tem certeza que deseja limpar a sess&atilde;o? <br><br> 
                        <a href="index.php" class="nao"> Não </a> <a href="index.php?act=clear&conf=y" class="sim"> Sim </a></div>';
                
                if(isset($_GET['act']) && $_GET['act'] == 'clear' && isset($_GET['conf']) && $_GET['conf'] == 'y'){
                    session_unset();
                    $_SESSION['data'] = date('d/m/Y');
                }
            }//Limpar Eventos
            
            
            //Apagar Evento
            if(isset($_GET['apagar']))
            {
                
                echo '<div class="msgBox"> Tem certeza que deseja apagar o evento? <br><br> 
                        <a href="index.php" class="nao"> Não </a> <a href="index.php?apagar='. $_GET['apagar'] .'&conf=y" class="sim"> Sim </a></div>';

                if(isset($_GET['apagar']) && isset($_GET['conf']) && $_GET['conf'] == 'y')
                    $eventos->apagarEvento($_GET['apagar']);
                    
            }//Apagar Evento

            if(isset($_POST['args']) && $_POST['args']=='insereEvento')
            {
                $eventos->inserirEvento($_SESSION['ultimoId']);
            }
            if(isset($_POST['args']) && $_POST['args']=='editaEvento')
            {
                $eventos->editarEvento();
            }
            ?>
            
           
            <div id="calendario" class="calendario">

                <?php
                $calendario->addAno();
                
                $data = $_SESSION['data'];
                
                if(isset($_POST['args']) && $_POST['args']=='mudarCalendario')
                {
                    $data = '01/'.$_POST['mes'].'/'.$_POST['ano'];
                }
                
                $calendario->constroiCalendario($data);
                ?>
                
            </div><!-- Calendário -->
            
            <div id="eventos" class="eventos">
            
                <?php
                $eventos->exibirEventos($_SESSION['data']);
                ?>
            
            </div>
            
            <div class="clear"></div>
            
            <div id="editaEvt"></div>
            
        </div><!-- content_calendario -->
        
        <?php 
            $formVal = array(0=>'insereEvento', 1=>'', 2=>'', 3=>'', 4=>'', 5=>'', 6=>'', 7=>'', 8=>'', 9=>'', 10=>'Gravar');
            if(isset($_GET['editar']) && isset($_SESSION['eventos'][$_GET['editar']])):

                $formVal = array(0=>'editaEvento', 
                                 1=>$_SESSION['eventos'][$_GET['editar']]['id'],
                                 2=>$_SESSION['eventos'][$_GET['editar']]['data'], 
                                 3=>$_SESSION['eventos'][$_GET['editar']]['nome'], 
                                 4=>$_SESSION['eventos'][$_GET['editar']]['tipo'], 
                                 5=>$_SESSION['eventos'][$_GET['editar']]['local'], 
                                 6=>$_SESSION['eventos'][$_GET['editar']]['inicio'], 
                                 7=>$_SESSION['eventos'][$_GET['editar']]['termino'], 
                                 8=>$_SESSION['eventos'][$_GET['editar']]['observacoes'], 
                                 9=>'disabled',
                                 10=>'Salvar Alterações');
            endif;
        ?>
        
        <div id="content_evento">
            <form name="formAddEvt" id="formAddEvt" class="formAddEvt" method="post" action="index.php">

                <input type="hidden" name="args" value="<?php echo $formVal[0]; ?>">
                <input type="hidden" name="addEvtId" value="<?php echo $formVal[1]; ?>">
               
                <label for="addEvtData"> Data   : </label>
                <input type="text" name="addEvtData" id="addEvtData" class="addEvtData" value="<?php echo $formVal[2]; ?>" maxlength="10" placeholder="Ex.: 01/05/2018">
                
                <label for="addEvtNome"> Nome   : </label>
                <input type="text" name="addEvtNome" id="addEvtNome" class="addEvtNome" value="<?php echo $formVal[3]; ?>" maxlength="50" placeholder="Escolha um nome">
                
                <label for="addEvtTipo"> Tipo   : </label>
                <input type="text" name="addEvtTipo" id="addEvtTipo" class="addEvtTipo" value="<?php echo $formVal[4]; ?>" maxlength="20" placeholder="Ex.: Festa"><br>
                
                <label for="addEvtLocal"> Local   : </label>
                <input type="text" name="addEvtLocal" id="addEvtLocal" class="addEvtLocal" value="<?php echo $formVal[5]; ?>" maxlength="80" placeholder="Ex.: Rua xxx, n 120">
                
                <label for="addEvtInicio"> Início : </label>
                <input type="text" name="addEvtInicio" id="addEvtInicio" class="addEvtInicio" value="<?php echo $formVal[6]; ?>" maxlength="6" placeholder="Ex.: 09:00">
                
                <label for="addEvtTermino"> Término: </label>
                <input type="text" name="addEvtTermino" id="addEvtTermino" class="addEvtTermino" value="<?php echo $formVal[7]; ?>" maxlength="6" placeholder="Ex.: 09:00"><br>
                
                <label for="addEvtObs"> Anotações: </label>
                <textarea name="addEvtObs" id="addEvtObs" class="addEvtObs" maxlength="150"><?php echo $formVal[8]; ?></textarea><br>
                
                <label for="addEvtRepetir"> Repetir: </label>
                <textarea name="addEvtRepetir" id="addEvtRepetir" class="addEvtRepetir" maxlength="addEvtRepetir" placeholder="Ex.: 02/07/2018, 05/03/2019" <?php echo $formVal[9]; ?>></textarea><br>
                
                <input type="submit" id="addEvtSubmit" class="addEvtSubmit" value="<?php echo $formVal[10]; ?>">
            </form>
        </div><!-- content_calendario -->

        </div><!-- wrapper -->
    </body>
</html>
