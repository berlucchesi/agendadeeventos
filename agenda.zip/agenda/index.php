<?php
session_start();
session_unset();

$_SESSION['eventos'] = array();
$_SESSION['ultimoId']= 0;
$_SESSION['anos']    = array();

$_SESSION['anos'][] = 2017;
$_SESSION['anos'][] = 2018;
$_SESSION['anos'][] = 2019;

$_SESSION['data'] = date('d/m/Y');


?>
<html>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <head>
    <!-- 
    @Autor:   Bernardo Figueiredo Lucchesi
    @Contato: bernardolucchesi@gmail.com
    @Site:    www.brnardo.com.br
    -->
    <title>Agenda de Eventos</title>
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat|Poiret+One" rel="stylesheet">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
    <script src="js/ajax.js"></script>
   
    </head>
    
    <body id="corpo">
        <div id="descricao" class="wrapper">
        <a id="expandir" class="expandir" href="#"> + </a>
        <p>
        <h2> - Agenda de Eventos - </h2><br>
        A ideia desse sistema é poder controlar meus eventos.<br>
        Assim, devo poder incluir um evento, editar, remover e consultar. Também quero poder ao criar um evento marcar para repetir o mesmo em outros dias, semanas, etc.
        Cada evento deve ter um id único, nome, local, início, término, opção de repetição e tipo do evento (deixo à vontade os tipos possíveis, seja criativo! )
        Os eventos devem ser exibidos na forma de agenda, tendo pelo menos as visões mensal e semanal, podendo navegar nas datas (semelhante aos calendários existentes).
        Todas as ações (criação, exclusão, alteração) devem trazer um alerta de realizado ou de erro.
        Os dados não precisam ser persistidos em banco, pode ser em memória mesmo.
        </p>
        
        <ul class="requisitos_do_sistema">
            <li>Incluir um evento, editar, remover e consultar;</li>
            <li>Ao criar um evento marcar para repetir o mesmo em outros dias, semanas, etc;</li>
            <li>Cada evento deve ter um id único, nome, local, início, término, opção de repetição e tipo do evento (deixo à vontade os tipos possíveis, seja criativo! )</li>
            <li>Os eventos devem ser exibidos na forma de agenda, tendo pelo menos as visões mensal e semanal, podendo navegar nas datas (semelhante aos calendários existentes).</li>
            <li>Todas as ações (criação, exclusão, alteração) devem trazer um alerta de realizado ou de erro.</li>
            <li>Os dados não precisam ser persistidos em banco, pode ser em memória mesmo.</li>
        </ul>
        <div class="clear"></div>
        
        <p>
        Linguagem: Fica a seu critério, desde que seja Web (ex: Java, NodeJs, Ruby, etc).
        </p>
        
        <p class="ct">Obrigatório:</p>
        <p class="ct">Diferenciais:</p>
        <p class="ct">O que será avaliado:</p>
        <div class="clear"></div>
        <ul>
            <li>Arquivo explicando como rodar o sistema</li>
            <li>Modelo(s)</li>
            <li>Controller(s)</li>
            <li>Telas</li>
            <li>Funcionalidades listadas acima</li>
        </ul>
        
        <ul>
            <li>Requisições assíncronas</li>
            <li>Estilização das telas</li>
            <li>Uso de framework de tela (Angular, ReactJS, JSF, etc)</li>
            <li>Testes (Unitários e/ou de Integração)</li>
            <li>Docker</li>
        </ul>

        <ul>
            <li>Corretude do sistema</li>
            <li>Organização do código</li>
            <li>Comentários úteis</li>
            <li>Abordagem utilizada</li>
        </ul>
        <div class="clear"></div>
        </div><!-- Wrapper -->
        
        <div id="content_calendario" class="wrapper">
        
            <a id="expandir_calendario" class="expandir_calendario" href="#"> + </a>
            <p>
            <h2> - Calendário - </h2><br></p>
            <p id="msgCalendario"></p>
           
            <div id="calendario" class="calendario">

                <?php 
                require_once('model/calendario.model.php');
  
                $calendario = new Calendario;
                $calendario->constroiCalendario($_SESSION['data']);
                ?>
                
            </div><!-- Calendário -->
            <div id="eventos" class="eventos">
            
                <?php
                require_once('model/eventos.model.php');
  
                $eventos = new Eventos;
                $eventos->exibirEventos($_SESSION['data']);
                ?>
            
            </div>
            <div class="clear"></div>
            
            <div id="editaEvt"></div>
            
        </div><!-- content_calendario -->

        <div id="content_eventos" class="wrapper">
        
            <a id="expandir_eventos" class="expandir_eventos" href="#"> + </a>
            <p>
            <h2> - Eventos - </h2><br></p>
            
            <p id="msgEvento" class="msgEvento"></p>
            
            <form id="form_addEvento" method="POST" action="">
        
                <label for="addEvento_data"> Data: </label>
                <input type="text" name="addEvento_data" id="addEvento_data" maxlength="10" placeholder="Ex. 28/09/2018">
                
                <label for="addEvento_nome"> Nome: </label>
                <input type="text" name="addEvento_nome" id="addEvento_nome" maxlength="25" placeholder="nome do evento">
                
                <label for="addEvento_nome"> Tipo: </label>
                <select name="addEvento_tipo" id="addEvento_tipo">
                    <option value="Festa"> Festa </option>
                    <option value="Feriado"> Feriado </option>
                    <option value="Médico"> Médico </option>
                    <option value="Passeio"> Passeio </option>
                    <option value="Reunião"> Reunião </option>
                    <option value="Trabalho"> Trabalho </option>
                    <option value="Outros"> Outros </option>
                </select><br><br>
                
                <label for="addEvento_local"> Local: </label>
                <input type="text" name="addEvento_local" id="addEvento_local" maxlength="100" placeholder="local do evento">
                
                <label for="addEvento_inicio"> Horário de Início: </label>
                <input type="text" name="addEvento_inicio" id="addEvento_inicio" maxlength="5" placeholder="Ex. 08:45">
                
                <label for="addEvento_termino"> Horário de Término: </label>
                <input type="text" name="addEvento_termino" id="addEvento_termino" maxlength="5" placeholder="Ex.: 15:15"><br><br>
                
                <label for="addEvento_obs"> Observações: </label>
                <textarea name="addEvento_obs" id="addEvento_obs" placeholder=""></textarea><br>
                
                <label for="addEvento_repetir"> Repetir evento nas datas: (insira todas as datas em que este evento se repetirá, separando por vírgulas) </label>
                <textarea name="addEvento_repetir" id="addEvento_repetir" placeholder="Exemplo: 01/01/2018, 01/02/2018, 01/03/2018, ..."></textarea><br>
                
                <input type="button" name="addEvento_btn" id="addEvento_btn" value="SALVAR">
                
            </form>

        </div>
        
    </body>
</html>
