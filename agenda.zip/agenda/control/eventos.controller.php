<?php
@session_start();

require_once('../model/eventos.model.php');

if(isset($_POST['args']) && !empty($_POST['args']))
{
    
    $args = json_decode(stripslashes($_POST['args']));
    
    switch($args[0]){
            
        case 'insereEvento':
            insereEvento($args);
        break;
            
        case 'exibeEventos':
            exibeEventos();
        break;   
            
        case 'apagaEvento':
            apagaEvento($args);
        break;
            
        case 'editaEvento':
            editaEvento($args);
        break;  
            
        default:
            
    }//switch
    
}

function insereEvento($args)
{
    $eventos = new Eventos;
    $eventos->inserirEvento($args);
}

function exibeEventos()
{
    $eventos = new Eventos;
    $eventos->exibirEventos('01/01/2018');
}

function apagaEvento($args)
{
    $eventos = new Eventos;
    $eventos->apagarEvento($args);
}

function editaEvento($args)
{
    $eventos = new Eventos;
    $eventos->editarEvento($args);
}

?>
