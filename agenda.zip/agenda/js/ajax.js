/*
@Autor:   Bernardo Figueiredo Lucchesi
@Contato: bernardolucchesi@gmail.com
@Site:    www.brnardo.com.br
*/


//Expandir Janelas
        
$(document).ready(function() {
    
    jQuery("#content_calendario").addClass('largo');
        
    $('#expandir').click(function(){
        jQuery("#descricao").addClass('largo');  
        jQuery("#content_calendario").removeClass('largo');  
        jQuery("#content_eventos").removeClass('largo');  
    });
    
    $('#expandir_calendario').click(function(){
        jQuery("#descricao").removeClass('largo');  
        jQuery("#content_calendario").addClass('largo');  
        jQuery("#content_eventos").removeClass('largo');  
    });
    
    $('#expandir_eventos').click(function(){
        jQuery("#descricao").removeClass('largo');  
        jQuery("#content_calendario").removeClass('largo');  
        jQuery("#content_eventos").addClass('largo');  
    });
    
});

function carregaFuncao(url, funcao)
{
        
    var args = new Array();
    switch (funcao){
        case 'carregaCalendario':
            args[0] = funcao;
            args[1] = document.getElementById("form_mes").value;
            args[2] = document.getElementById("form_ano").value;
            break;
        default:
    }
    
    var strDados = JSON.stringify(args);
    
    $.ajax({
        url: url,
        method: "POST",
        data: {args: strDados},
        success: function(data) {
            $('#calendario').html(data);
        }
    });
    
}
        
        
$(document).ready(function(){
    
    $(document).on('click', '#escolheCalendario', function() {
        carregaFuncao('control/calendario.controller.php', 'carregaCalendario');
    });
    
}); 

function exibeEventos(url, funcao)
{
    
    var args = new Array();
    args[0] = 'exibeEventos';
    var strDados = JSON.stringify(args);
    
    $.ajax({
        url: url,
        method: "POST",
        data: {args: strDados},
        success: function(data) {
            $('#eventos').html(data);
        }
    });
    
    return 1;
    
}



function inserirEvento(url, funcao)
{
    
    var args = new Array();
    
    args[0] = 'insereEvento';
    args[1] = document.getElementById("addEvento_data").value;
    args[2] = document.getElementById("addEvento_nome").value;
    args[3] = document.getElementById("addEvento_tipo").value;
    args[4] = document.getElementById("addEvento_local").value;
    args[5] = document.getElementById("addEvento_inicio").value;
    args[6] = document.getElementById("addEvento_termino").value;
    args[7] = document.getElementById("addEvento_obs").value;
    args[8] = document.getElementById("addEvento_repetir").value;
    
    var strDados = JSON.stringify(args);
    

    $.ajax({
        url: url,
        method: "POST",
        data: {args: strDados},
        success: function(data) {
            $('#msgEvento').html(data);
        }
    });

    return 1;
    
}


$(document).ready(function(){
    
    $(document).on('click', '#addEvento_btn', function() {

        inserirEvento('control/eventos.controller.php', 'insereEvento');

        exibeEventos('control/eventos.controller.php', 'exibeEventos');
        
    });
    
}); 


function apagarEvento(url, funcao, id)
{
    
    var args = new Array();
    args[0] = 'apagaEvento';
    args[1] = id;
    
    var strDados = JSON.stringify(args);
    

    $.ajax({
        url: url,
        method: "POST",
        data: {args: strDados},
        success: function(data) {
            $('#msgCalendario').html(data);
        }
    });

    return 1;
    
}

function apagaEvento(id)
{
    var confirma = confirm("Quer mesmo apagar o registro?");
    if(confirma){
        apagarEvento('control/eventos.controller.php', 'exibeEventos', id);
        exibeEventos('control/eventos.controller.php', 'exibeEventos');
    }
}

/*************************************
           Editar Eventos
*************************************/
function editarEventoForm(url, funcao, id)
{
    
    var args = new Array();
    args[0] = 'editaEvento';
    args[1] = id;
    
    var strDados = JSON.stringify(args);
    

    $.ajax({
        url: url,
        method: "POST",
        data: {args: strDados},
        success: function(data) {
            $('#editaEvt').html(data);
        }
    });

    return 1;
    
}

function editaEventoForm(id)
{
    editarEventoForm('control/eventos.controller.php', 'editaEventos', id);
}
