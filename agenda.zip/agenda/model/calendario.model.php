<?php

class Calendario
{
    
    private $nome_meses = array('01'=>'JANEIRO',  '02'=>'FEVEREIRO', '03'=>'MAR&Ccedil;O', '04'=>'ABRIL', 
                                '05'=>'MAIO',     '06'=>'JUNHO',     '07'=>'JULHO',        '08'=>'AGOSTO', 
                                '09'=>'SETEMBRO', '10'=>'OUTUBRO',   '11'=>'NOVEMBRO',     '12'=>'DEZEMBRO');
    
    private $dias_meses = array('01' => 31, '02' => 28, '03' => 31, '04' =>30, 
                                '05' => 31, '06' => 30, '07' => 31, '08' =>31, 
                                '09' => 30, '10' => 31, '11' => 30, '12' => 31);
    
    private $dias_semana= array(0 => 'DOM', 1 => 'SEG', 2 => 'TER', 3 => 'QUA', 4 => 'QUI', 5 => 'SEX', 6 => 'S&Aacute;B');


    function addAno($ano)
    {

        if(in_array($ano, $_SESSION['anos'])):
            return;
        endif;
        
        $_SESSION['anos'][] = $ano;
        return;

    }
    
    function optionAnos($array, $data)
    {
        
        $data = explode('/', $data);
        $ano = $data[2];
        
        if(empty($array)):
            echo '<option value="2018"> 2018 </option>';
            return;
        endif;
        
        asort($array);
        
        foreach ( $array as $a):
        
            if($a == $ano):
                echo '<option value="'.$a.'" SELECTED>'.$a.'</option>';
            else:
                echo '<option value="'.$a.'">'.$a.'</option>';
            endif;
        
        endforeach;
        
    }
    
    function optionMeses( $data )
    {
        
        
        $data = explode('/', $data);
        $kmes = $data[1];
        
        foreach ($this->nome_meses as $key => $a):
            if($key == $kmes):
                echo '<option value="'.$key.'" SELECTED>'.$a.'</option>';
            else:
                echo '<option value="'.$key.'">'.$a.'</option>';
            endif;
        endforeach;
        
    }
    
    function bissexto($ano)
    {
        if(date('L', mktime(0, 0, 0, 1, 1, $ano)) == 1)
        {
            return $this->dias_meses['02'] = 29;
        }
        
        return;
    }
    
    function imprimeSemana()
    {
        
        echo '<tr class="cabecalho_semana">';
        
        foreach ($this->dias_semana as $a):
            echo '<td>'.$a.'</td>';
        endforeach;
        
        echo '</tr>';
    }
    
    function proximoMes( $data )
    {
        
        $data = explode('/', $data);
        $mes = $data[1];
        $ano = $data[2];
        
        if($mes == 12):
            $mes = '01';
            $ano ++;
        else:
            $mes++;
        endif;
        
        $mes = str_pad($mes, 2, '0', STR_PAD_LEFT);
        
        return '01/'.$mes.'/'.$ano;
    }
    
    function anteriorMes( $data )
    {
        
        $data = explode('/', $data);
        $mes = $data[1];
        $ano = $data[2];
        
        if($mes == '01'):
            $mes = '12';
            $ano --;
        else:
            $mes--;
        endif;
        
        $mes = str_pad($mes, 2, '0', STR_PAD_LEFT);
        
        return '01/'.$mes.'/'.$ano;
        
    }
    
    function menuCalendario( $data )
    {
        
        echo '<form method="POST" action="">
                <label> <a href="#" id="voltarMes"> &laquo; </a> </label>
                
                <select name="mes" id="form_mes">';
        
        $this->optionMeses( $data );
        
        echo '  </select>
                <select name="ano" id="form_ano">';
        
        $this->optionAnos($_SESSION['anos'], $data);
        
        echo '  </select>
        
                <input type="button" id="escolheCalendario" value="BUSCAR">
        
                <label> <a href="#" id="avancarMes"> &raquo; </a> </label>
              </form>';
                
        return;
        
    }
    
    function constroiCalendario( $data )
    {
        
        $this->menuCalendario( $data );
        
        $data = explode('/', $data);
        $this->bissexto($data[2]);
        
        $primeiro_dia = date('w', strtotime($data[2].'-'.$data[1].'-01'));
        
        echo '<table>
                <tr class="cabecalho"><td colspan="7"> '.$this->nome_meses[$data[1]].' / '.$data[2].' </td></tr>';
        
        $this->imprimeSemana();
        
        $cont  = 0;
        
        while($cont < 42){
            
            if($cont % 7 == 0) echo '<tr>';
            
            if($cont < $primeiro_dia || ($cont - $primeiro_dia >= $this->dias_meses[$data[1]])):
                echo '<td> &nbsp; </td>';
            else:
                echo '<td> '. ($cont - $primeiro_dia +1) .' </td>';
            endif;
            
            if($cont % 7 == 6) echo '</tr>';
            
            $cont++;
        }
        
        echo '</table>';

    }
    
}

?>
























