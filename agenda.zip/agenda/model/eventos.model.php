<?php

@session_start();

class Eventos
{
    
    function exibirEventos($data)
    {
        
        if(empty($_SESSION['eventos'])):
            echo 'Não existem eventos cadastrados.';
            return;
        endif;
        
        foreach($_SESSION['eventos'] as $a):
            echo '<p>'.$a['id'].' - '.$a['data'].' - '.$a['nome'];
            echo '<a id="deletarEvento" href="#" onClick="apagaEvento('.$a['id'].')"> Apagar </a>
                  <a id="editaEventoBtn" href="#" onClick="editaEventoForm('.$a['id'].')"> Editar </a>';
            echo '</p>';
        endforeach;
        
        return;
        
    }
    
    function inserirEvento($args)
    {
        
        if($_SESSION['ultimoId']==0):
            $evtId = 1;
        else:
            $evtId = $_SESSION['ultimoId']+1;
        endif;
        
        $_SESSION['ultimoId'] = $evtId;
        
        $_SESSION['eventos'][$evtId]['id']         = $evtId;
        $_SESSION['eventos'][$evtId]['data']       = $args[1];
        $_SESSION['eventos'][$evtId]['nome']       = $args[2];
        $_SESSION['eventos'][$evtId]['tipo']       = $args[3];
        $_SESSION['eventos'][$evtId]['local']      = $args[4];
        $_SESSION['eventos'][$evtId]['inicio']     = $args[5];
        $_SESSION['eventos'][$evtId]['termino']    = $args[6];
        $_SESSION['eventos'][$evtId]['observacoes']= $args[7];
        
        echo 'Sucesso! Id: '.$evtId;
        
    }
    
    function apagarEvento($args)
    {
        unset($_SESSION['eventos'][$args[1]]);
        echo 'Evento: '.$args[1].' deletado.';
    }
    
    function editarEvento($args)
    {
        echo '<form name="formEditaEventos" id="formEditaEventos" class="formEditaEventos">
                <label for="editaData">Data</label>
                <input type="text" name="editaData" id="editaData" class="editaData" value="'.$_SESSION['eventos'][$args[1]]['data'].'">
                
                <input type="button" id="btnEditaEvento" value="Salvar Alterações">
              </form>';
    }
    
}

?>